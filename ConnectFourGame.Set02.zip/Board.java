package EGE;

public class Board {
    public static final int ROWS = 6;
    public static final int COLUMNS = 7;
    private final char[][] grid;

    public Board() {
        grid = new char[ROWS][COLUMNS];
        // Initialize the board with dots ('.') for empty cells
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                grid[i][j] = '.';
            }
        }
    }

    /**
     * Attempts to drop a tile (X or O) into the specified column.
     * @param col   The column number (0 to 6)
     * @param token The player's token ('X' or 'O')
     * @return      true if the tile was placed, false if the column is full or invalid
     */
    public boolean dropTile(int col, char token) {
        if (col < 0 || col >= COLUMNS) {
            return false;  // invalid column
        }
        // Start from the bottom row and move upwards
        for (int row = ROWS - 1; row >= 0; row--) {
            if (grid[row][col] == '.') {
                grid[row][col] = token;
                return true;
            }
        }
        return false;  // column is full
    }

    /**
     * Checks if the board is full (i.e., 42 tiles have been placed).
     * @return true if no more moves can be made, false otherwise
     */
    public boolean isFull() {
        for (int col = 0; col < COLUMNS; col++) {
            if (grid[0][col] == '.') {
                return false;
            }
        }
        return true;
    }

    /**
     * Prints the board in the requested format.
     * <p>
     * Example format:
     * 00 01 02 03 04 05 06
     * ---------------------
     * . . . . . . .
     * . . . . . . .
     * . . . . . . .
     * . . . . . . .
     * . . . . . . .
     * . . . . . . .
     * ---------------------
     */
    public void printBoard() {
        // Print column headers as two-digit numbers
        for (int col = 0; col < COLUMNS; col++) {
            System.out.printf("%02d ", col);
        }
        System.out.println();
        System.out.println("---------------------");

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                System.out.print(grid[row][col] + " ");
            }
            System.out.println();
        }
        System.out.println("---------------------");
    }

    /**
     * Checks if a player with the given token has won (4 in a row).
     * @param token 'X' or 'O'
     * @return      true if there's a four-in-a-row, false otherwise
     */
    public boolean checkWin(char token) {
        // Horizontal check
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col <= COLUMNS - 4; col++) {
                if (grid[row][col] == token &&
                        grid[row][col+1] == token &&
                        grid[row][col+2] == token &&
                        grid[row][col+3] == token) {
                    return true;
                }
            }
        }
        for (int col = 0; col < COLUMNS; col++) {
            for (int row = 0; row <= ROWS - 4; row++) {
                if (grid[row][col] == token &&
                        grid[row+1][col] == token &&
                        grid[row+2][col] == token &&
                        grid[row+3][col] == token) {
                    return true;
                }
            }
        }
        for (int row = ROWS - 1; row >= 3; row--) {
            for (int col = 0; col <= COLUMNS - 4; col++) {
                if (grid[row][col] == token &&
                        grid[row-1][col+1] == token &&
                        grid[row-2][col+2] == token &&
                        grid[row-3][col+3] == token) {
                    return true;
                }
            }
        }
        for (int row = 0; row <= ROWS - 4; row++) {
            for (int col = 0; col <= COLUMNS - 4; col++) {
                if (grid[row][col] == token &&
                        grid[row+1][col+1] == token &&
                        grid[row+2][col+2] == token &&
                        grid[row+3][col+3] == token) {
                    return true;
                }
            }
        }
        return false;
    }
}
