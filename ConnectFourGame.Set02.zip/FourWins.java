package EGE;

    import java.util.Scanner;

    public class FourWins {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            Board board = new Board();

            Player playerX = new Player("Player X", 'X');
            Player playerO = new Player("Player O", 'O');
            Player currentPlayer = playerX;
            boolean gameWon = false;

            while (!board.isFull() && !gameWon) {
                board.printBoard();

                System.out.print(currentPlayer.getName() + " (" + currentPlayer.getToken() + "), choose a column (0-6): ");
                int col;
                try {
                    col = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number between 0 and 6.");
                    continue;
                }

                if (!board.dropTile(col, currentPlayer.getToken())) {
                    System.out.println("Column " + col + " is full or invalid. Try again.");
                    continue;
                }

                if (board.checkWin(currentPlayer.getToken())) {
                    board.printBoard();
                    System.out.println(currentPlayer.getName() + " wins!");
                    gameWon = true;
                } else {

                    currentPlayer = (currentPlayer == playerX) ? playerO : playerX;
                }
            }

            if (!gameWon) {
                board.printBoard();
                System.out.println("The game is a draw!");
            }
            scanner.close();
        }
    }

